﻿using MlHostApi.Tools;

namespace MlHostApi.Models
{
    public class HostAssignment
    {
        public string? HostName { get; set; }

        public string? ModelId { get; set; }
    }
}
