﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MlHostApi.Models
{
    public class PingResponse
    {
        public string? Status { get; set; }

        public string? ModelId { get; set; }

        public string? HostName { get; set; }

        public string? LastException { get; set; }
    }
}
