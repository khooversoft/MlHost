﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MlHostApi.Models
{
    public class QuestionRequest
    {
        public string? Question { get; set; }
    }
}
