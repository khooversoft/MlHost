﻿using MlHostApi.Tools;
using System;
using System.Collections.Generic;
using System.Text;

namespace MlHostApi.Option
{
    public class KeyVaultOption
    {
        public string? KeyVaultName { get; set; }

        public string? KeyName { get; set; }
    }
}
