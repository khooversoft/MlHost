﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Azure.Storage;
using Azure.Storage.Files.DataLake;
using Azure.Storage.Files.DataLake.Models;
using MlHostApi.Tools;

namespace MlHostApi.Repository
{
    public class DataLakeRepository
    {
        private readonly string _containerName;
        private readonly DataLakeServiceClient _serviceClient;
        private readonly DataLakeFileSystemClient _fileSystem;

        public DataLakeRepository(string accountName, string accountKey, string containerName)
        {
            containerName.VerifyNotEmpty(nameof(containerName));
            accountKey.VerifyNotEmpty(nameof(accountKey));
            containerName.VerifyNotEmpty(nameof(containerName));

            _containerName = containerName;

            StorageSharedKeyCredential sharedKeyCredential = new StorageSharedKeyCredential(storageAccountName, storageAccountKey);
            var serviceUri = new Uri($"https://{accountName}.blob.core.windows.net");

            // Create DataLakeServiceClient using StorageSharedKeyCredentials
            _serviceClient = new DataLakeServiceClient(serviceUri, sharedKeyCredential);

            // Get a reference to a filesystem (container)
            _fileSystem = _serviceClient.GetFileSystemClient(containerName);
        }

        public async Task Delete(string path, CancellationToken token)
        {
            path.VerifyNotEmpty(nameof(path));

            DataLakeFileClient file = _fileSystem.GetFileClient(path);
            await file.DeleteIfExistsAsync(cancellationToken: token);
        }

        public async Task Download(string path, Stream toStream, CancellationToken token)
        {
            path.VerifyNotEmpty(nameof(path));
            toStream.VerifyNotNull(nameof(toStream));

            DataLakeFileClient file = _fileSystem.GetFileClient(path);
            await file.ReadToAsync(toStream, cancellationToken: token);
        }

        public async Task Upload(Stream fromStream, string toPath, bool force, CancellationToken token)
        {
            fromStream.VerifyNotNull(nameof(fromStream));
            toPath.VerifyNotEmpty(nameof(toPath));

            DataLakeFileClient file = _fileSystem.GetFileClient(toPath);
            await file.UploadAsync(fromStream, force, token);
        }

        public async Task<DatalakePathProperties?> GetPathProperties(string path, CancellationToken token) => (await List(path, token)) != null;

        public async Task<DatalakePathItem?> List(string path, CancellationToken token)
        {
            await foreach (PathItem blobItem in _fileSystem.GetPathsAsync(path, true, cancellationToken: token))
            {
                return blobItem.ConvertTo();
            }

            return null;
        }

        public async Task<byte[]> Read(string path, CancellationToken token)
        {
            path.VerifyNotEmpty(nameof(path));

            BlobClient blobClient = _containerClient.GetBlobClient(path);
            BlobDownloadInfo download = await blobClient.DownloadAsync();

            using MemoryStream memory = new MemoryStream();
            await download.Content.CopyToAsync(memory);

            return memory.ToArray();
        }

        public async Task Write(string path, byte[] data, CancellationToken token)
        {
            path.VerifyNotEmpty(nameof(path));
            data
                .VerifyNotNull(nameof(data))
                .VerifyAssert(x => x.Length > 0, $"{nameof(data)} length must be greater then 0");

            await _containerClient.DeleteBlobIfExistsAsync(path, cancellationToken: token);

            using var memoryBuffer = new MemoryStream(data.ToArray());
            await _containerClient.UploadBlobAsync(path, memoryBuffer, token);
        }

        public async Task<IReadOnlyList<BlobInfo>> Search(string prefix, Func<string, bool> filter, CancellationToken token)
        {
            var list = new List<BlobInfo>();

            await foreach (BlobItem blobItem in _containerClient.GetBlobsAsync(prefix: prefix, cancellationToken: token))
            {
                if (filter(blobItem.Name)) list.Add(blobItem.ConvertTo());
            }

            return list;
        }
    }
}
