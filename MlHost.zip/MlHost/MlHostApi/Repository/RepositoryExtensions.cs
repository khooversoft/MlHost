﻿using Azure.Storage.Blobs.Models;
using Azure.Storage.Files.DataLake.Models;
using MlHostApi.Tools;

namespace MlHostApi.Repository
{
    public static class RepositoryExtensions
    {
        public static BlobInfo ConvertTo(this BlobItem subject)
        {
            subject.VerifyNotNull(nameof(subject));

            return new BlobInfo
            {
                Name = subject.Name,
                LastModified = subject.Properties.LastModified,
                CreatedOn = subject.Properties.CreatedOn,
                ETag = subject.Properties.ETag?.ToString(),
                ContentHash = subject.Properties.ContentHash,
                ContentType = subject.Properties.ContentType,
                ContentLength = subject.Properties.ContentLength,
            };
        }

        public static DatalakePathItem ConvertTo(this PathItem subject)
        {
            return new DatalakePathItem
            {
                Name = subject.Name,
                IsDirectory = subject.IsDirectory,
                LastModified = subject.LastModified,
                ETag = subject.ETag.ToString(),
                ContentLength = subject.ContentLength,
                Owner = subject.Owner,
                Group = subject.Group,
                Permissions = subject.Permissions,
            };
        }

        public static DatalakePathProperties ConvertTo(this PathProperties subject)
        {
            return new DatalakePathProperties
            {
                LastModified = subject.LastModified,
                ContentEncoding = subject.ContentEncoding,
                ContentHash = subject.ContentHash,
                ETag = subject.ETag.ToString(),
                ContentType = subject.ContentType,
                ContentLength = subject.ContentLength,
                CreatedOn = subject.CreatedOn,
            };
        }
    }
}
