﻿namespace MlHostApi.Services
{
    public interface ITelemetry
    {
        void WriteLine(string message);
    }
}